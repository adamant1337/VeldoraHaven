(function(){
  'use strict';
  if (typeof IntersectionObserver === 'undefined') return;

  var io = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -48px 0px' });

  function init() {
    var els = document.querySelectorAll(
      '.shopify-section, .card-wrapper, .vh-hiw-step, .vh-trust-item, .vhc-hero__content'
    );
    els.forEach(function(el) {
      el.classList.add('vh-reveal');
      io.observe(el);
    });
    var delay = document.querySelectorAll(
      '.vh-hiw-step:nth-child(2), .vh-trust-item:nth-child(2)'
    );
    delay.forEach(function(el) { el.classList.add('vh-reveal-delay-1'); });
    var delay2 = document.querySelectorAll(
      '.vh-hiw-step:nth-child(3), .vh-trust-item:nth-child(3)'
    );
    delay2.forEach(function(el) { el.classList.add('vh-reveal-delay-2'); });
    var delay3 = document.querySelectorAll(
      '.vh-hiw-step:nth-child(4), .vh-trust-item:nth-child(4)'
    );
    delay3.forEach(function(el) { el.classList.add('vh-reveal-delay-3'); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
