# VELDORA HAVEN — STORE CONTENT PACK
*Policies · Email Flows · Supplier Applications*
*Generated 2026-07-31 — Copy and paste directly into Shopify and Klaviyo*

---

# PART 1 — LEGAL POLICIES (Prompt 3)
*Paste each section into: Settings → Policies → [section]*

---

## PRIVACY POLICY
*Settings → Policies → Privacy Policy*

**Last updated: July 2026**

Veldora Haven (veldorahaven.com) is operated by a Danish sole proprietorship registered under Danish law. We are committed to protecting the privacy and personal data of our customers.

**1. What Information We Collect**

When you place an order or browse our store, we may collect:
- Name, email address, shipping address, and phone number
- Payment information (processed securely by Stripe and PayPal — we never store card numbers)
- Order history and product preferences
- Browser type, IP address, and pages visited (via cookies and analytics)

**2. How We Use Your Information**

We use your information to:
- Process and fulfill your order
- Forward your shipping details to our supplier partners for direct delivery
- Send order confirmation and tracking emails
- Respond to customer service enquiries
- Send marketing emails if you have opted in (you can unsubscribe at any time)
- Improve our website and customer experience

**3. Sharing Your Information**

We share your name, shipping address, and order details with our supplier partners solely to fulfill your order. We do not sell your personal information to third parties.

We may share anonymised, aggregated data with advertising platforms (Google, Meta) for marketing purposes. We may also share data with service providers (Shopify, Klaviyo, Judge.me) under data processing agreements.

**4. Data Retention**

We retain your personal data for as long as necessary to fulfill the purposes outlined in this policy, typically for 5 years in accordance with Danish accounting law.

**5. Cookies**

Our store uses cookies for functionality, analytics, and marketing. You can manage your cookie preferences via the cookie consent banner on our site. Essential cookies cannot be disabled as they are required for the store to function.

**6. Your Rights (GDPR)**

If you are located in the EU or EEA, you have the right to:
- Access the personal data we hold about you
- Correct inaccurate personal data
- Request deletion of your personal data (subject to legal obligations)
- Object to processing for marketing purposes
- Request data portability

To exercise any of these rights, contact us at: info@veldorahaven.com

We will respond to all requests within 30 days.

**7. Data Security**

We use industry-standard SSL encryption for all data transmitted through our store. Payment processing is handled exclusively by Stripe and PayPal, which are PCI-DSS compliant.

**8. Third-Party Services**

Our store is powered by Shopify. You can review Shopify's privacy practices at https://www.shopify.com/legal/privacy. Order notifications are managed via Klaviyo; product reviews via Judge.me.

**9. Contact**

For privacy-related enquiries: info@veldorahaven.com
Veldora Haven | Denmark

---

## TERMS OF SERVICE
*Settings → Policies → Terms of Service*

**Last updated: July 2026**

These Terms of Service govern your use of veldorahaven.com and any purchase you make from Veldora Haven. By placing an order, you agree to be bound by these terms.

**1. About Veldora Haven**

Veldora Haven (veldorahaven.com) is operated by a Danish sole proprietorship. We operate a dropshipping model: when you place an order, we forward it to our supplier partner, who ships the product directly to your address. Products ship from the manufacturer's warehouse, not from a Veldora Haven facility. We never take physical possession of the products we sell.

**2. Eligibility**

You must be at least 18 years old to purchase from Veldora Haven. By placing an order, you confirm that you meet this requirement.

**3. Product Information**

We make every effort to display product descriptions, specifications, and images accurately. Minor differences between product images and the actual product may occur. Product specifications (dimensions, BTU output, material finishes) are provided by manufacturers and are subject to change without notice.

**4. Pricing**

All prices are listed in US Dollars (USD). Prices are subject to change at any time. We reserve the right to correct pricing errors. Tax is applied at checkout where applicable.

**5. Payment**

We accept Visa, Mastercard, American Express, Discover, PayPal, and other payment methods offered at checkout. Payment is charged at the time of order placement.

**6. Order Confirmation and Acceptance**

An order confirmation email does not constitute acceptance of your order. We reserve the right to cancel orders due to product unavailability, pricing errors, or suspected fraudulent activity.

**7. Order Cancellation**

Orders may be cancelled for a full refund within 24 hours of placement, before forwarding to the supplier. After 24 hours, cancellation may not be possible for large items shipped via freight. Contact us immediately at info@veldorahaven.com if you need to cancel.

**8. Delivery and Freight**

Large items (saunas, hot tubs, pergolas, outdoor kitchens) ship via LTL freight. Delivery times are estimates and not guaranteed. You are responsible for ensuring adequate site access for freight delivery. Veldora Haven is not liable for delays caused by the carrier or supplier.

**9. White Glove Delivery**

White glove delivery and installation services are available for an additional fee quoted at checkout or on request. This service is provided by the supplier or third-party contractor and is subject to their terms.

**10. Limitation of Liability**

To the fullest extent permitted by law, Veldora Haven's liability is limited to the purchase price of the product. We are not liable for incidental, consequential, or punitive damages.

**11. Governing Law**

These Terms are governed by Danish law. Any disputes shall be subject to the exclusive jurisdiction of the Danish courts.

**12. Changes to These Terms**

We reserve the right to modify these Terms at any time. The version in effect at the time of your order governs that transaction.

**Contact:** info@veldorahaven.com

---

## REFUND POLICY
*Settings → Policies → Refund Policy*

**Last updated: July 2026**

**Overview**

Veldora Haven operates a dropshipping model — products ship directly from the manufacturer to your door. Our return and refund process reflects this: we coordinate returns directly with our supplier partners on your behalf.

**30-Day Return Window — Eligible Items**

Most products may be returned within 30 days of confirmed delivery for a full refund of the product price, subject to the conditions below. Original freight shipping costs and return freight costs are non-refundable. You are responsible for arranging and paying for return freight.

**Return Conditions**

To be eligible for a return, items must be:
- Returned within 30 days of confirmed delivery
- In original, unused, uninstalled condition
- In original manufacturer packaging
- Free from signs of assembly, use, or modification

**Non-Returnable Items**

The following items cannot be returned:

- Products that have been installed, assembled, used, or modified in any way
- Custom-configured or special-order items (including custom outdoor kitchen configurations)
- Items returned after 30 days from delivery
- Items returned without prior written authorisation from Veldora Haven
- Products where freight damage was not reported within 48 hours of delivery (see Freight Damage below)

**Freight Damage — Critical: 48-Hour Rule**

All large items (saunas, pergolas, hot tubs, outdoor kitchens) ship via LTL freight. Before signing for delivery, inspect the packaging carefully. If you notice damage:

1. Note it on the delivery driver's paperwork before signing
2. Photograph the damaged packaging and product immediately
3. Contact us within 48 hours of delivery at info@veldorahaven.com with photos

Freight damage claims reported after 48 hours cannot be honoured. We are unable to process insurance claims or supplier replacements for late-reported damage.

**Manufacturer Warranty**

All products sold by Veldora Haven carry the manufacturer's full warranty. Warranty claims are handled directly by the manufacturer; we will assist in facilitating claims on your behalf.

Typical warranty coverage:
- Saunas: 1–5 year structural warranty (varies by brand)
- Cold Plunge & Hot Tubs: 1–2 year parts warranty
- Outdoor Kitchens & Grills: Lifetime structural warranty on stainless steel
- Pergolas: 5-year frame warranty, 2 years on moving parts
- Fire Features: 1 year manufacturer warranty

**How to Initiate a Return**

1. Email info@veldorahaven.com with your order number and reason for return
2. We will respond with return authorisation within 1 business day
3. Do not ship any item back without prior written authorisation — unauthorised returns cannot be processed
4. Once the supplier confirms receipt of the return, a refund will be issued

**Refund Processing**

Approved refunds are issued to the original payment method within 5–10 business days of supplier confirmation. You will receive an email notification when the refund is processed.

**Contact**

For return requests or warranty assistance: info@veldorahaven.com
Response time: within 1 business day, 7 days a week.

---
---

# PART 2 — JUDGE.ME REVIEW REQUEST EMAIL (Prompt 4)
*Set up in Judge.me → Email Templates → Review Request*
*Send timing: 14 days after order fulfillment*

---

## SUBJECT LINE
Your Veldora Haven experience — a quick note from us

---

## EMAIL BODY (HTML version — paste into Judge.me template editor)

Hi {{customer_name}},

It's been a couple of weeks since your **{{product_title}}** arrived, and we hope it's already become a part of your daily outdoor life.

At Veldora Haven, we believe the best outdoor spaces are earned slowly — built up over seasons, shaped by the products you choose and how you use them. Your perspective on what you bought matters to us, and it matters to the next customer who's weighing a decision like yours.

**Would you take two minutes to share your experience?**

[Leave a Review →] ← *Link to Judge.me review form*

There are no right or wrong answers. Whether it's how the product looks in your space, how delivery went, or something that surprised you — we'd love to hear it. Five stars or not, honest reviews help us serve customers better.

As always, if anything about your order needs attention, reply to this email and you'll reach a real person — usually within a couple of hours.

Thank you for choosing Veldora Haven.

— The Veldora Haven Team
hello@veldorahaven.com | veldorahaven.com

---

## JUDGE.ME SETUP INSTRUCTIONS

**Step 1 — Access email templates:**
Judge.me Dashboard → Emails → Review Request

**Step 2 — Timing:**
Set "Days after fulfillment" to: **14**

**Step 3 — Subject line:**
`Your Veldora Haven experience — a quick note from us`

**Step 4 — Widget placement on product pages:**
Judge.me Dashboard → Widgets → Review Widget → set position to "Below product description"

**Step 5 — Star rating badge (appears below product title):**
Judge.me Dashboard → Widgets → Star Rating Badge → enable → position: "Below product title"

**Step 6 — Color customization:**
Judge.me Dashboard → Appearance:
- Star color: `#C8A96E` (gold)
- Primary color: `#1B4332` (forest green)
- Button background: `#C8A96E`
- Button text: `#1B4332`
- Font: match body font (Inter or system)

**Step 7 — Enable photo reviews:**
Judge.me Dashboard → Settings → Reviews → enable "Allow photo reviews" — essential for high-ticket products where customers photograph their installations.

---
---

# PART 3 — KLAVIYO EMAIL FLOWS (Prompt 5)
*Set up in Klaviyo → Flows → Create Flow*

---

## FLOW 1: ABANDONED CART (3 emails)

### Email 1 — Sent: 1 hour after cart abandonment

**Subject:** You left something behind

**Preview text:** Your outdoor living upgrade is still waiting.

---

Hi {{first_name|default:'there'}},

You were looking at some beautiful things.

Your **{{abandoned_cart_items}}** is still in your cart at veldorahaven.com. We just wanted to make sure you didn't lose it.

**[Return to your cart →]**

If you have any questions before you decide — about sizing, delivery, installation, or anything else — hit reply. We're available 7 days a week and typically respond within a couple of hours.

— Veldora Haven
veldorahaven.com

---

### Email 2 — Sent: 24 hours after cart abandonment

**Subject:** A few things worth knowing before you decide

**Preview text:** Free freight. Full warranty. Direct from the manufacturer.

---

Hi {{first_name|default:'there'}},

You were browsing **{{abandoned_cart_items}}** at Veldora Haven. We thought it was worth sharing a few things that might help you decide:

**Free freight shipping** — every large item ships directly from the manufacturer to your door, included in the price. No hidden delivery fees.

**Full manufacturer warranty** — you get the same warranty you'd receive buying directly from the brand. We're an authorised reseller.

**Direct delivery** — your product ships from the factory, handled with care, insured against freight damage.

**Expert support** — have a question about installation, site preparation, or which model fits your space? We're here to help, 7 days a week.

**[Complete your order →]** ← link to abandoned cart

Still deciding? That's completely fine. These are significant purchases and deserve proper consideration. If you'd like to talk through your options, just reply to this email.

— The Veldora Haven Team
hello@veldorahaven.com

*You're receiving this because you added items to your cart at veldorahaven.com.*

---

### Email 3 — Sent: 72 hours after cart abandonment

**Subject:** Still thinking it over?

**Preview text:** We're happy to answer any questions before you decide.

---

Hi {{first_name|default:'there'}},

This is our last reminder about the **{{abandoned_cart_items}}** waiting in your cart.

If price, delivery, or installation is giving you pause — we'd genuinely like to help. Reply to this email and tell us what's on your mind. We answer every email personally, and we know these products well.

**[View your cart →]** ← link to abandoned cart

Whatever you decide, thank you for considering Veldora Haven. We're here if you need us.

— The Veldora Haven Team
hello@veldorahaven.com | veldorahaven.com

---

## FLOW 2: WELCOME SERIES (2 emails)

### Welcome Email 1 — Sent: Immediately after signup

**Subject:** Welcome to Veldora Haven

**Preview text:** Premium outdoor living, delivered direct.

---

Welcome to Veldora Haven.

You've just joined a community of homeowners who believe that the best life happens outside — and that the products you surround yourself with should reflect that.

**What we offer:**

[SAUNAS]
Cedar and hemlock barrel saunas, infrared cabin saunas, outdoor wellness cabins — from $4,500
→ veldorahaven.com/collections/saunas

[COLD PLUNGE]
Chiller-equipped cold plunge tubs, portable ice baths, premium all-in systems — from $480
→ veldorahaven.com/collections/cold-plunge-ice-baths

[OUTDOOR KITCHENS]
Modular BBQ islands, built-in grills, outdoor pizza ovens, stainless cabinetry — from $900
→ veldorahaven.com/collections/outdoor-kitchens

[HOT TUBS & BATHS]
Wood-fired Nordic hot tubs, luxury plug-and-play Jacuzzi spas — from $5,800
→ veldorahaven.com/collections/outdoor-baths-hot-tubs

[FIRE & PERGOLAS]
Gas fire pit tables, luxury patio heaters, aluminium louvre pergolas — from $1,100
→ veldorahaven.com/collections/fire-features

Every product ships direct from the manufacturer to your door. Free freight. Full warranty. No inventory games.

**[Explore the full collection →]** ← veldorahaven.com

We're available 7 days a week if you have questions.

— The Veldora Haven Team
hello@veldorahaven.com

---

### Welcome Email 2 — Sent: 3 days after signup

**Subject:** How Veldora Haven works — and why it matters

**Preview text:** You pay us. We order for you. The factory ships to you.

---

Hi {{first_name|default:'there'}},

We want to be transparent about how Veldora Haven works — because we think it's actually a reason to choose us.

**The model in plain English:**

1. You place an order at veldorahaven.com and pay us
2. We immediately forward your order to the manufacturer
3. The manufacturer ships the product directly to your address

That's it. We never hold inventory. We never touch your product. It ships factory-fresh, in the manufacturer's original packaging, with the manufacturer's full warranty — exactly as if you'd ordered directly from the brand.

**Why does this matter to you?**

Because you get factory-quality at a fair price. We negotiate wholesale relationships with the world's best outdoor living manufacturers so that you benefit from competitive pricing, authorised dealer warranties, and direct shipping — without the warehouse markups that traditional retailers add.

**What we handle:**
- Finding and vetting the best manufacturers
- Maintaining dealer relationships so you have warranty coverage
- Handling your order, coordinating shipment, and supporting you before and after delivery

**The result:** A better product experience than most traditional retailers, at pricing that reflects reality.

Questions? Just reply — we're here.

— The Veldora Haven Team
hello@veldorahaven.com | veldorahaven.com

---

## KLAVIYO SETUP INSTRUCTIONS

**Abandoned Cart Flow:**
1. Klaviyo Dashboard → Flows → Create from Scratch
2. Trigger: "Checkout Started" (or "Started Checkout" metric from Shopify)
3. Add filter: "Has not placed order since starting this flow"
4. Email 1: wait 1 hour → send
5. Email 2: wait 23 more hours → send
6. Email 3: wait 48 more hours → send
7. Add exit condition: "Placed Order" (stop flow if they buy)

**Welcome Series Flow:**
1. Flows → Create → trigger: "Subscribed to List"
2. Select your main list (created on store signup form)
3. Email 1: 0 delay → send immediately
4. Email 2: wait 3 days → send
5. Add exit condition: "Placed Order" within 3 days (skip Email 2 if they've already bought)

**Sending domain:** Set up in Klaviyo → Account → Sender Profiles → add hello@veldorahaven.com

---
---

# PART 4 — SUPPLIER APPLICATION EMAILS (Prompt 9)

---

## EMAIL 1: ORIVON WELLNESS ★★ (HIGHEST PRIORITY)
*Apply at: orivonwellness.com/partner*

**Subject:** Dealer Application — Veldora Haven | Premium US Outdoor Living E-Commerce

---

Dear Orivon Wellness Team,

I'm writing to apply for a dealer/reseller partnership with Orivon Wellness.

**About Veldora Haven**

Veldora Haven (veldorahaven.com) is a premium outdoor living e-commerce brand serving affluent US homeowners. Our product catalogue covers the complete backyard wellness experience — saunas, cold plunge tubs, outdoor kitchens, hot tubs, pergolas, and fire features. We operate a pure dropship model: customers order on our platform, and we forward orders to our supplier partners for direct fulfilment.

**Our Target Customer**

We serve homeowners aged 35–60 with household income of $120K+, typically purchasing $3,000–$15,000 products for backyard wellness and outdoor entertaining. These are informed, research-driven buyers who are willing to pay a premium for quality and trust.

**Why Orivon Wellness Fits Our Catalogue**

Orivon covers both the sauna and cold plunge categories — our two highest-demand product families. We currently have strong interest in both the cold plunge tub range and the Sauna + Cold Plunge bundle configuration, which aligns precisely with the contrast therapy trend driving our category.

**Business Details**
- Business name: Veldora Haven
- Operating entity: Danish sole proprietorship (EU VAT registered)
- Website: veldorahaven.com
- Contact email: hello@veldorahaven.com
- Model: Pure dropship — authorised reseller, customer pays us, we pay wholesale to supplier

I would welcome the opportunity to discuss our partnership further and understand your wholesale programme requirements.

Best regards,
[Your Name]
Veldora Haven
hello@veldorahaven.com
veldorahaven.com

---

## EMAIL 2: CAL FLAME ★★
*Apply at: calflame.com/dealers*

**Subject:** Dealer Application — Veldora Haven | Premium US Outdoor Kitchen E-Commerce

---

Dear Cal Flame Dealer Relations Team,

I'm writing to apply for an authorised dealer relationship with Cal Flame.

**About Veldora Haven**

Veldora Haven (veldorahaven.com) is a premium outdoor living e-commerce brand focused on the affluent US homeowner market. We specialise in high-quality outdoor kitchens, saunas, cold plunge systems, and luxury outdoor living products. We operate a dropship model — customers order through our platform, and we forward fulfilment to our authorised supplier partners.

**Target Customer**

Our customers are homeowners aged 35–60 with significant purchasing power, actively investing in their outdoor living spaces. Average order values in our outdoor kitchen category typically exceed $3,500, reflecting the serious buyer we serve.

**Cal Flame's Fit**

Cal Flame's modular BBQ island systems — particularly the 7-foot configurations with integrated grills, refrigerators, and storage — are exactly the type of premium, permanent outdoor kitchen installation our customers are seeking. The Cal Flame brand reputation and US manufacturing credentials are important trust signals for our audience.

**Business Details**
- Business name: Veldora Haven
- Website: veldorahaven.com (launching actively — please review)
- Email: hello@veldorahaven.com
- Resell model: Pure dropship / authorised reseller

I look forward to understanding your dealer application requirements and the products available for reseller programmes.

Best regards,
[Your Name]
Veldora Haven | hello@veldorahaven.com

---

## EMAIL 3: ALMOST HEAVEN SAUNAS ★
*Apply at: almostheavensaunas.com — Contact / Dealer page*

**Subject:** Dealer Enquiry — Veldora Haven | Outdoor Sauna E-Commerce

---

Dear Almost Heaven Saunas Team,

I'm writing to enquire about a dealer/reseller relationship with Almost Heaven Saunas.

**About Veldora Haven**

Veldora Haven (veldorahaven.com) is a premium e-commerce destination for outdoor living products serving the US market. Our sauna category currently features products from several manufacturers, and we are looking to add an authorised Almost Heaven relationship to ensure customers receive proper warranty coverage and post-purchase support.

Our customers are typically homeowners investing $4,500–$14,000 in a sauna for their backyard wellness setup. The Almost Heaven cedar and hemlock barrel sauna range — particularly the Salem 2-person and Watoga 4-person models — fits perfectly into our catalogue positioning.

**What We're Asking**
- Wholesale pricing for the cedar and hemlock barrel sauna range
- Dropship fulfilment from your facility directly to our end customers
- Authorised reseller status for warranty passthrough

**Business Details**
- Business: Veldora Haven | veldorahaven.com
- Email: hello@veldorahaven.com
- Model: E-commerce dropship, US market

Thank you for considering this partnership. I'm happy to provide any additional information needed.

Best regards,
[Your Name]
Veldora Haven | hello@veldorahaven.com

---

## EMAIL 4: SUMMERSET GRILLS ★
*Apply at: summersetgrills.com/dealer*

**Subject:** Dealer Application — Veldora Haven | Premium Outdoor Kitchen Platform

---

Dear Summerset Professional Grills Dealer Team,

I'm reaching out to apply for a dealer relationship with Summerset.

**About Veldora Haven**

Veldora Haven (veldorahaven.com) is a premium outdoor living e-commerce brand serving affluent US homeowners. Our outdoor kitchen category currently includes grill islands, built-in grills, pizza ovens, and refrigeration. We're looking to add Summerset's professional-grade built-in grill range to our catalogue.

The Summerset brand — with its professional stainless construction, strong warranty programme, and US warehouse distribution — aligns well with what our customers expect. We serve buyers who are willing to pay a premium for lasting quality and won't be drawn to lower-specification alternatives.

**Our Model**

We operate a pure dropship reseller model. Customers order on our platform, we pay wholesale to the supplier, and the supplier ships directly to the customer's address. Our focus is on providing premium product curation and a trusted buying experience — not competing on price.

**Business Details**
- Business: Veldora Haven | veldorahaven.com
- Email: hello@veldorahaven.com
- Location: Danish sole proprietorship, US market focus

I look forward to hearing about your dealer programme requirements.

Best regards,
[Your Name]
Veldora Haven | hello@veldorahaven.com

---

## EMAIL 5: BULL OUTDOOR PRODUCTS ★
*Apply at: bullbbq.com/dealer*

**Subject:** Dealer Application — Veldora Haven | US Outdoor Kitchen E-Commerce

---

Dear Bull Outdoor Products Team,

I'm writing to apply for a dealer/reseller relationship with Bull Outdoor Products.

**About Veldora Haven**

Veldora Haven (veldorahaven.com) is a premium outdoor living e-commerce brand targeting affluent US homeowners. We sell high-quality outdoor kitchens, saunas, cold plunge systems, and luxury backyard products — all via a dropship model with direct fulfilment from our supplier partners.

We're specifically interested in Bull's weatherproof stainless outdoor kitchen cabinet and storage systems, which complement our existing modular grill island range. Bull's product quality, broad catalogue, and established US distribution make it an ideal fit for our outdoor kitchen category.

**Business Details**
- Business: Veldora Haven | veldorahaven.com
- Email: hello@veldorahaven.com
- Model: Authorised reseller / dropship, US market

We're ready to complete any dealer application form and provide business documentation as required. Looking forward to hearing from you.

Best regards,
[Your Name]
Veldora Haven | hello@veldorahaven.com

---
---

# PART 5 — PAYMENTS SETUP GUIDE (Prompt 3 — Manual Steps)

## STRIPE SETUP
1. Go to admin.shopify.com/store/iqeb6u-5h/settings/payments
2. Under "Shopify Payments" — if not set up: click "Complete account setup" and connect Stripe through Shopify's native integration
3. If you prefer a separate Stripe account: click "Choose third-party provider" → search "Stripe" → Connect
4. Enter your Stripe account credentials or create one at stripe.com
5. Enable: Visa, Mastercard, Amex, Discover (all checked by default)
6. Currency: USD ✓
7. Statement descriptor: VELDORAHAVEN
8. Save

## PAYPAL SETUP
1. Same page → scroll to "Alternative payment methods"
2. Click "Add payment methods" → select "PayPal"
3. Click "Activate PayPal" → you'll be redirected to PayPal
4. Log into your PayPal business account (or create one at paypal.com/business)
5. Authorise the Shopify connection
6. Return to Shopify — PayPal Express should show as "Active"

## TESTING
After setup: place a test order using Shopify's test payment card:
- Card number: 4111 1111 1111 1111
- Expiry: Any future date | CVV: Any 3 digits
- Refund the test order after confirming it processes correctly

