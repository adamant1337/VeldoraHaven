# VELDORAHAVEN BUILD AGENT
> Always read this file at the start of every session. It is the single source of truth.
> Last updated: 2026-07-31

---

## 1. BUSINESS OVERVIEW

**Brand:** Veldora Haven | **Tagline:** Outdoor Living, Elevated.
**Domain target:** veldorahaven.com (NOT yet connected — priority)
**Current store URL:** iqeb6u-5h.myshopify.com (epiccard.dk — still primary domain)
**Model:** Pure dropship — zero inventory, customer pays first, we pay supplier, supplier ships direct
**Target customer:** Affluent US homeowners 35–60, HHI $120K+
**Plan email:** hello@veldorahaven.com
**Business entity:** Danish sole proprietorship (CVR + VAT registered)
**NO financing/BNPL on the store** — Affirm skipped, no monthly payment messaging anywhere

---

## 2. SHOPIFY STORE — CURRENT STATE

### Store Details
| Item | Value |
|---|---|
| Store name | VeldoraHaven |
| Admin URL | admin.shopify.com/store/iqeb6u-5h |
| Primary domain | iqeb6u-5h.myshopify.com (epiccard.dk — needs switching to veldorahaven.com) |
| Plan | Shopify (paid) |
| Shopify publication ID | gid://shopify/Publication/343904747862 |
| Location ID | gid://shopify/Location/119205757270 |

### Themes
| ID | Name | Role |
|---|---|---|
| 200545665366 | Horizon | UNPUBLISHED |
| 200577581398 | VeldoraHaven | UNPUBLISHED |
| 200629977430 | Epiccard v1 | UNPUBLISHED |
| 204033786198 | VeldoraHaven — Ready to Publish | UNPUBLISHED |
| 204035359062 | VeldoraHaven — Auroom Style | UNPUBLISHED |
| 204036702550 | VeldoraHaven — Full Build | UNPUBLISHED |
| 204041748822 | VeldoraHaven — v3 Category Cards | UNPUBLISHED |
| **204053348694** | **VeldoraHaven — v4 Final** | **MAIN (live) ✅** |
| **204085330262** | **VeldoraHaven — v5 No Financing** | **MAIN (live) ✅** |
| 204085854550 | VeldoraHaven — v6 Clean | **READY TO PUBLISH** |

**NEXT PUBLISH:** v6 Clean (204085854550) — announcement bar cleaned (no more "Financing from $99/month"), settings_data cleaned. Logo still needs manual set via Customizer.

**EpicCard blogs:** ✅ All deleted — only "Outdoor Living" blog remains (ID: 127871877462).

### Design System
| Scheme | Background | Use |
|---|---|---|
| scheme-1 | #F7F7F5 cream | Default light sections |
| scheme-2 | #EAF2EC mist | Alternate light |
| scheme-3 | #1B4332 forest green | Header, hero, dark sections |
| scheme-4 | #152e25 deep forest | Footer |

**Hero image (Shopify CDN, 3200px):**
`https://cdn.shopify.com/s/files/1/1029/5620/4374/files/turn-on-the-sun-3200.jpg?v=1785423094`

**CSS selector for hero:** `.hero-wrapper .hero__media-grid` (background-image injection, SVG/img set to opacity:0)

### Products (21 active, all published, NO financing in descriptions)
| Product | ID | Price | Images |
|---|---|---|---|
| Cedar Barrel Sauna — 2 Person | 10883194093910 | $4,500 | 4 |
| Hemlock Barrel Sauna — 4 Person | 10883195404630 | $6,800 | 4 |
| Infrared Cabin Sauna — 2 Person | 10883196551510 | $6,500 | 2 |
| Outdoor Cabin Sauna — 4 to 6 Person | 10883198779734 | $12,000 | 9 |
| Sauna + Cold Plunge Bundle | 10883199533398 | $14,000 | 4 |
| Chiller-Equipped Cold Plunge Tub | 10883215688022 | $5,500 | 3 |
| Premium Cold Plunge with Advanced Filtration | 10883216408918 | $9,500 | 2 |
| Portable Ice Bath Tub | 10883217260886 | $480 | 2 |
| Modular Grill Island — 7ft Stainless Steel | 10883218571606 | $3,800–$4,200 | 3 |
| Outdoor Pizza Oven — Wood & Gas | 10883219423574 | $2,200–$2,800 | 3 |
| Outdoor Stainless Steel Refrigerator | 10883220177238 | $1,600 | 2 |
| Wood-Fired Nordic Hot Tub | 10883220865366 | $5,800 | 3 |
| Luxury Plug & Play Hot Tub — 5 Person | 10883222733142 | $9,500 | 4 |
| Premium Gas Fire Pit Table | 10883224011094 | $2,200 | 3 |
| Luxury Outdoor Sectional Furniture Set | 10883224699222 | $5,500 | 2 |
| Luxury Aluminium Pergola — 12x16ft | 10883226173782 | $7,500 | 11 |
| Built-In Gas BBQ Grill — 36" Stainless Steel | 11154919752022 | $1,800 | 2 |
| Weatherproof Outdoor Kitchen Cabinet Set | 11154919817558 | $2,800 | 2 |
| Electric Sauna Heater — 9kW | 11154919850326 | $900 | 2 |
| Freestanding Cold Plunge — Orivon Frost | 11154919883094 | $3,800 | 2 |
| Luxury Outdoor Patio Heater — 38,000 BTU | 11154919948630 | $1,100 | 3 |

### Collections (7 VeldoraHaven, all published)
| Collection | Handle | Products |
|---|---|---|
| Outdoor Kitchens | outdoor-kitchens | 5 |
| Saunas | saunas | 5 |
| Cold Plunge & Ice Baths | cold-plunge-ice-baths | 5 |
| Outdoor Baths & Hot Tubs | outdoor-baths-hot-tubs | 2 |
| Fire Features | fire-features | 2 |
| Outdoor Furniture & Pergolas | outdoor-furniture-pergolas | 2 |
| Complete Bundles | complete-bundles | 0 ⚠️ (bundle add API cached — verify) |

### Pages (6 live, all VeldoraHaven)
Contact Us, About Us, FAQ, Shipping & Delivery, Returns & Warranty, How It Works

### Navigation
- Main Menu: gid://shopify/Menu/318495228246 — 7 category dropdowns ✅
- Footer Menu: gid://shopify/Menu/318495261014 ✅

### Blog
Blog ID: gid://shopify/Blog/127871877462 — "Outdoor Living"
3 posts: Best Barrel Saunas 2026 / Cold Plunge Buyer's Guide / How to Design Outdoor Kitchen
EpicCard blogs (Nyheder, Collector's Corner) — still need deletion from admin

---

## 3. APPS INSTALLED (Peter confirmed)
- ✅ Judge.me — free product reviews
- ✅ Klaviyo — email marketing (free up to 250 contacts)
- ✅ CookieYes — GDPR cookie consent
- Tidio or similar for live chat (to confirm)
- ❌ Affirm / BNPL — SKIPPED (no financing on this store)

---

## 4. LOCAL IMAGES
**Photo library:** `C:\VeldoraHavenBilleder` — 40+ files confirmed present
Key files:
- `VeldoraHaven_Logo_Transparent.png` — main logo (334KB PNG)
- `VeldoraHaven_Logo_Header.png` — header variant
- `vh_hero_turn_on_sun_3200px.jpg` — hero image (local copy)
- `auroom_*.jpg` — 13 Auroom sauna/wellness lifestyle shots
- `mirador_pergola_*.jpg/png` — 6 Mirador pergola product shots
- `bullfrog_a8_*.png` — 3 Bullfrog hot tub images
- `calflame_*.webp` — 5 Cal Flame BBQ island shots
- `OutdoorKitchenisland.avif` — outdoor kitchen lifestyle (AVIF format)
- `premium_photo-*.avif` — additional lifestyle photo

---

## 5. WHAT STILL NEEDS TO BE DONE

### IMMEDIATE (next session)
- [ ] Publish "VeldoraHaven — v5 No Financing" theme (Online Store → Themes)
- [ ] Set logo via Shopify Customizer (Online Store → Themes → Customize → Header → Logo image → upload VeldoraHaven_Logo_Transparent.png, set height 50px)
- [ ] Upload OutdoorKitchenisland.avif to Outdoor Kitchen products for better featured images
- [ ] Fix Complete Bundles collection (verify bundle is in it — may need manual check)
- [ ] Delete old EpicCard blogs ("Nyheder", "Collector's Corner") from admin
- [ ] Connect veldorahaven.com as primary domain (Settings → Domains)
- [ ] Configure Stripe + PayPal (Settings → Payments)
- [ ] Add 3 legal policies (Settings → Policies — Privacy Policy, Terms of Service, Refund Policy)

### WEEK 1
- [ ] Set up Judge.me review request email (14 days post delivery)
- [ ] Set up Klaviyo abandoned cart flow (3-email: 1h / 24h / 72h)
- [ ] Set up Klaviyo post-purchase review request
- [ ] Add "You might also like" cross-sell to product pages
- [ ] Add phone number to header and contact page
- [ ] Add collection banners/hero images to collection pages
- [ ] Upgrade furniture product images (current featured image is weak)
- [ ] Write announcements bar content (e.g. "Free freight shipping on all orders")

### BUSINESS
- [ ] Apply to suppliers: Orivon Wellness ★★, Cal Flame ★★, Almost Heaven, Summerset, Bull
- [ ] Add remaining products from business plan (Luxury Jetted Spa $14K, Outdoor Soaking Tub $3.2K)
- [ ] Register @veldorahaven on Instagram, Pinterest, TikTok, YouTube

---

## 6. TECHNICAL RULES
- **CRITICAL**: Always verify store is VeldoraHaven (iqeb6u-5h) — not EpicCard
- **Live theme writes are blocked** — always duplicate, write to draft, Peter publishes
- **GitHub is one-directional** — Shopify → GitHub, not reverse
- **Push script:** C:\Temp\gitpull_push.ps1
- **No financing/BNPL anywhere** — Peter's decision, skip Affirm
- **image_picker settings can't accept URLs** — use CSS background-image workaround
- **Always push to GitHub** after completing tasks

---

## 7. KEY CDN URLS (all on Shopify CDN)
| Asset | URL |
|---|---|
| Hero 3200px | https://cdn.shopify.com/s/files/1/1029/5620/4374/files/turn-on-the-sun-3200.jpg?v=1785423094 |
| Mirador Pergola Hero | https://cdn.shopify.com/s/files/1/1029/5620/4374/files/Mirador_Pergola_HZ_1327-u_Custom_-1_4566b998-bb4b-484d-8f16-c60b49ac769d.png?v=1785423112 |

---

## 8. THE NEXT 10 PROMPTS

### PROMPT 1 — Publish v5 + set logo + announcements bar
> "Publish the VeldoraHaven — v5 No Financing theme. Then set the store logo: go to Online Store → Themes → Customize → Header → upload VeldoraHaven_Logo_Transparent.png from C:\VeldoraHavenBilleder, set height 50–55px. Also add an announcements bar with the text: 'Free Freight Shipping on All Orders to the Contiguous US'. Push everything to GitHub."

### PROMPT 2 — Connect veldorahaven.com domain + remove epiccard.dk
> "Connect veldorahaven.com as the primary domain for the Veldora Haven Shopify store. Walk me through the exact DNS records I need to set at my registrar (A record + CNAME). Once DNS propagates, remove epiccard.dk from the domain list and set veldorahaven.com as the primary. Verify the store is accessible at veldorahaven.com and epiccard.dk redirects correctly."

### PROMPT 3 — Configure Stripe + PayPal payments + legal policies
> "Set up payments for Veldora Haven: (1) Activate Stripe as the primary payment provider in Settings → Payments; (2) Add PayPal Express as a secondary method; (3) Write and paste the Privacy Policy, Terms of Service, and Refund Policy into Settings → Policies — customized for our dropship model (no returns on freight-damaged items reported after 48h, 30-day return window for unused items, supplier warranty passthrough, dropship disclosure). Walk me through each step."

### PROMPT 4 — Set up Judge.me review system
> "Configure the Judge.me review app on Veldora Haven. Set up the post-purchase review request email to go out 14 days after order fulfillment. Write the review request email copy (premium, on-brand tone — not generic). Add the review widget to all 21 product pages. Configure the Star Rating widget to show in the header of each product page. Ensure the widget design matches our forest green and gold color scheme."

### PROMPT 5 — Set up Klaviyo abandoned cart + welcome flow
> "Set up two core Klaviyo email flows for Veldora Haven: (1) Abandoned cart — 3 emails: 1 hour after abandonment (gentle reminder), 24 hours (address objections, mention free freight + warranty), 72 hours (final nudge, offer to answer questions). (2) Welcome series — 2 emails: immediate (brand intro + collections overview), 3 days later (how it works + our dropship model). Write all 5 email subject lines and body copy in the Veldora Haven brand tone. Include the store URL and product links."

### PROMPT 6 — Upload local images + fix product featured images
> "Upload these images from C:\VeldoraHavenBilleder to the correct Shopify products via Shopify's staged upload API: OutdoorKitchenisland.avif → Modular Grill Island product; premium_photo-*.avif → Outdoor Sectional Furniture; HOTTUB_03_nordic_wood_fired.jpg → Wood-Fired Nordic Hot Tub. Also fix the Luxury Outdoor Sectional Furniture featured image (current one is a weak Zuo Modern vendor shot — replace with a better lifestyle image from Auroom's folder). Reorder all product images so lifestyle shots appear first, product-only shots second."

### PROMPT 7 — Add collection page hero banners + improve collection pages
> "Each collection page currently shows just a grid of products with no header. Add a hero banner to each of the 7 collection pages: image, collection title in serif, short tagline, and a scroll-to-products CTA. Use images already uploaded to Shopify CDN. Collections: Saunas (auroom lifestyle), Cold Plunge (veleira ice bath), Outdoor Kitchens (Cal Flame island), Hot Tubs (Bullfrog A8), Fire Features (Warming Trends fire pit), Furniture & Pergolas (Mirador pergola), Complete Bundles (sauna + cold plunge lifestyle). Update the collection descriptions to match."

### PROMPT 8 — Add cross-sell + 'Complete Your Space' section to product pages
> "Build a cross-sell system for Veldora Haven product pages. Add a 'Complete Your Space' recommendation section at the bottom of each sauna product pointing to the matching cold plunge, and vice versa. For outdoor kitchen products, cross-sell the pergola and fire pit. Implement this via Shopify product metafields or a custom section in the product template. Also update the Sauna + Cold Plunge Bundle page to be a proper landing page with the sauna and cold plunge shown side by side."

### PROMPT 9 — Add supplier application tracker + write application emails
> "Write professional dealer application emails for each of the 5 priority suppliers: Orivon Wellness, Cal Flame, Almost Heaven Saunas, Summerset Grills, and Bull Outdoor Products. Each email should introduce Veldora Haven, describe the target customer (affluent US homeowners), explain the dropship model, mention the store (veldorahaven.com), and request a dealer/reseller application. Also create a tracking spreadsheet at C:\VeldoraHavenBilleder\SupplierApplications.xlsx with columns: Supplier, URL, Date Applied, Status, Contact Name, Notes."

### PROMPT 10 — SEO audit + Google Merchant Center + Google Shopping setup
> "Run an SEO audit of the Veldora Haven store: check all 21 product pages for missing meta titles, meta descriptions, and alt text on images. Fix any gaps. Then walk me through setting up Google Merchant Center for Veldora Haven: (1) Create and verify the account; (2) Add veldorahaven.com; (3) Create a Shopify → Google Shopping product feed; (4) Set up a Google Shopping campaign targeting US homeowners searching for outdoor kitchens, barrel saunas, and cold plunge tubs. Provide the exact campaign structure and keyword list."

---

## 9. SESSION START CHECKLIST (run every session)
1. Verify store name = VeldoraHaven (not EpicCard)
2. Read this agent file
3. Query themes — confirm which is MAIN
4. Note: NO financing mentions allowed anywhere on the store
5. Any EpicCard content visible = wrong store, switch immediately
